/**
 * 
 */
// document.querySelector("page-button").addEventListener("click", refreshCurrentPage());

// async function refreshCurrentPage() {
//     //
// }