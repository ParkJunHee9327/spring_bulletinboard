package com.jeho.spring.config;

import javax.servlet.Filter;
import javax.servlet.MultipartConfigElement;
import javax.servlet.ServletRegistration.Dynamic;

import org.springframework.web.filter.CharacterEncodingFilter;
import org.springframework.web.servlet.support.AbstractAnnotationConfigDispatcherServletInitializer;

public class WebConfig extends AbstractAnnotationConfigDispatcherServletInitializer {
	// 이 부분은 정말 모르는 게 많아서 다 뜯어봐야겠음.
	
	@Override
	// Class<?>가 뭐지? 제네릭인가?
	protected Class<?>[] getRootConfigClasses() {
		return new Class[] {MySQLConfig.class};  // SecurityConfig.class는 아직 없어서 일단 제외함.
	}
	
	@Override
	protected Class<?>[] getServletConfigClasses() {
		return new Class[] {ServletConfig.class};
	}
	
	@Override
	protected String[] getServletMappings() {
		return new String[] {"/"};
	}
	
	// encoding filter 설정
	@Override
	protected Filter[] getServletFilters() {
		CharacterEncodingFilter encoding = new CharacterEncodingFilter("UTF-8", true);
//		encoding.setEncoding("UTF-8");
//		encoding.setForceEncoding(true); // 외부로 나가는 데이터를 인코딩 할거냐는 것.
		
		return new Filter[] {encoding};
	}
	
	// 파일 업로드 사용자 지정
	@Override
	protected void customizeRegistration(Dynamic registration) {
		// 파일 업로드 위치 설정
		String uploadLocation = "D:\\_myProject\\_java\\_fileUpload";
		int maxFileSize = 1024*1024*20; // 20MB
		int maxReqSize = maxFileSize * 3; // 3개까지 첨부 가능
		int fileSizeThreshold = maxFileSize;
		
		MultipartConfigElement multipartConfig = 
				new MultipartConfigElement(uploadLocation, maxFileSize, maxReqSize, fileSizeThreshold);
		
		registration.setMultipartConfig(multipartConfig);
	}

}
