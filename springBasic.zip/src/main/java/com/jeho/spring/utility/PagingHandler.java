package com.jeho.spring.utility;

import com.jeho.spring.domain.Paging;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class PagingHandler {
	
	private int pageRange;
	private int startPage;
	private int endPage;
	private boolean canPrev;
	private boolean canNext;
	
	private int totalPost; // DB에서 가져올 예정.
	private Paging paging; // Paging의 currentPage
	
	private int realEndPage;
	// comment는 여기 넣을 게 아니라서 제외.
	
	public PagingHandler(int totalPost, Paging paging) {
		this.pageRange = 10; // 10개씩 보여줄 예정.
		this.paging = paging;
		this.totalPost = totalPost;
		
		// 보여줄 내용: 1~10, 11~20, 21~30...
		// currentPage = 1, 2, 3... => 1~10일 때.
		// currentPage = 11, 12, 13... => 11~10일 때.
		this.endPage = (int) Math.ceil(paging.getCurrentPage() / (double) pageRange) * pageRange;
		this.startPage = endPage - 9;
		
		// 실제 마지막 페이지
		// 전체 글 수 / 한 페이지에 표시되는 게시글 수 -> 올림한 값.
		// 글 개수가 마지막 페이지 10 + 1개면 아래 페이징은 10, 11을 띄워야 함.
		this.realEndPage = (int) Math.ceil(totalPost / (double) paging.getPostPerPage());
		
		// 이전과 다음이 있는지 판별
		this.canPrev = this.startPage > 1;
		this.canNext = this.endPage < this.realEndPage;
		
		if(endPage > realEndPage) {
			this.endPage = realEndPage;
		}
	}
}
