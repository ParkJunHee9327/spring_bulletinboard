package com.jeho.spring.utility;

import java.io.File;
import java.io.IOException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import org.apache.tika.Tika;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

import com.jeho.spring.domain.FileDTO;

import lombok.extern.slf4j.Slf4j;
import net.coobird.thumbnailator.Thumbnails;

@Slf4j
@Component
public class FileHandler {
	
	// 저장 경로
	private final String UPLOAD_DIR = "D:\\_myProject\\_java\\_fileUpload";
	
	// 첨부파일을 주고 FileDTO의 리스트로 변환하여 반환 및 저장
	public List<FileDTO> uploadFile(MultipartFile[] files) {
		
		List<FileDTO> fileList = new ArrayList<>();
		
		// FileDTO로 생성 + 파일 저장. 썸네일 저장 기능은 제외함.
		// 날짜별로 폴더 생성하여 업로드 파일 관리
		LocalDate date = LocalDate.now();
		log.info(" > Today is > {}", date.toString());
		String today = date.toString();
		today = today.replace("-", File.separator);
		
		File folders = new File(UPLOAD_DIR, today);
		
		// 폴더 생성(있으면 생성 안 함.): mkdir (1개만 생성) mkdirs(하위폴더까지 생성)
		if(!folders.exists()) {
			folders.mkdir();
		}
		
		// files를 가지고 fileList 생성
		for(MultipartFile file : files) {
			FileDTO fileDto = new FileDTO();
			fileDto.setDirPath(today);
			fileDto.setFileSize(file.getSize());
			
			// 경로를 포함하는 이름이라면...
			String fileName = file.getOriginalFilename().substring(
					file.getOriginalFilename().lastIndexOf(File.separator)+1);
			log.info("fileName {}", fileName);
			fileDto.setFileName(fileName);
			
			UUID uid = UUID.randomUUID();
			String uidStr = uid.toString();
			fileDto.setUid(uidStr);
			
			// fileDto 생성 완료 > post_num과 file_type(File 객체로 전달해야 해서 저장 후 확인)?? 뭔 말이야
			// 디스크에 저장 => 저장할 객체 (File)를 생성 및 저장
			String fullFileName = uidStr + "_" + fileName;
			File storeFile = new File(folders, fullFileName);
			
			try {
				file.transferTo(storeFile); // 저장
				
				// 썸네일 저장을 위해 이미지인지 확인한다는데
				// 나는 썸네일 안쓸거임. 작동되는지 확인만 하고 지울 것.
				if(isImageFile(storeFile)) {
					fileDto.setFileType(1); // 이미지 파일만 1
					// 썸네일 생성
					File thumbNail = new File(folders, uidStr + "_" + fileName);
					Thumbnails.of(storeFile).size(100, 100).toFile(thumbNail);
				}
			} catch (Exception e) {
				log.info("File saving error.");
				e.printStackTrace();
			}
			
			fileList.add(fileDto);
		}
		
		return fileList;
	}
	
	private boolean isImageFile(File storeFile) throws IOException {
		String mimeType = new Tika().detect(storeFile);
		return mimeType.startsWith("image") ? true : false;
	}
	
}
