package com.jeho.spring.utility;

import java.io.File;
import java.nio.file.Paths;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.jeho.spring.dao.FileDAO;
import com.jeho.spring.domain.FileDTO;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RequiredArgsConstructor
@Component
@EnableScheduling
public class FileSweeper {
	
	// 직접 DB 접속을 하여 처리
	private final FileDAO fileDao;
	private final String BASE_PATH = "D:\\_myProject\\_java\\_fileUpload\\";
	
	// 매일 정해진 시간에 스케줄러 실행
	// 매일 DB에 등록된 파일과 해당 일자의 폴더에 있는 파일이 일치하는 파일은 남기고
	// 일치하지 않는 파일이 있다면 삭제 (DB에는 없는데 폴더에는 남아있는 파일이 있다면 삭제)
	// file.delete() - fileRemoveHander를 사용하여 삭제해도 무방함.
	
	// cron을 사용하여 스케줄 기록.
	// (cron="59 59 23 * * *"): 매일 23시 59분 59초에 실행.
	@Scheduled(cron="0 15 13 * * *")
	public void fileSweeper() {
		log.info(" > FileSweeper operation starts: {}", LocalDateTime.now());
		
		// db에 등록된 모든 파일 목록 가져오기
		List<FileDTO> dbFileList = fileDao.selectAllFileList();
		
		// D:\_myProject\_java\_fileUpload\2024\11\04\\uid_파일명
		// D:\_myProject\_java\_fileUpload\2024\11\04\\uuid_th_파일명 => 이미지만 존재
		// 파일 경로 + 파일명을 붙인 실제 존재해야 하는 파일 리스트
		List<String> currFiles = new ArrayList<String>();
		for(FileDTO fileDto : dbFileList) {
			String filePath = fileDto.getDirPath() + File.separator + fileDto.getUid();
			String fileName = fileDto.getFileName();
			currFiles.add(BASE_PATH + filePath + "_" + fileName);
			
			// 이미지라면 썸네일 경로도 추가 = 이미지 파일은 1로 줌.
			if( fileDto.getFileType() > 0) {
				currFiles.add(BASE_PATH + filePath + "_th_" + fileName);
			}
		}
		log.info(" > currFiles > {}", currFiles);
		
		// 실제 파일 경로를 설정함.
		LocalDate now = LocalDate.now();
		String today = now.toString();
		today = today.replace("-", File.separator);
		
		// 경로를 기반으로 저장된 파일을 검색
		// D:\_myProject\_java\_fileUpload\2024\11\04
		File dir = Paths.get(BASE_PATH + today).toFile();
		// listFiles(): 경로 안에 있는 모든 파일을 배열로 반환
		File[] allFileObject = dir.listFiles();
		log.info(" > all saved file array > {}", allFileObject.toString());
		
		// 실제 저장된 파일 목록과 DB의 존재 파일을 비교하여 DB에 없는 파일은 삭제
		for(File file : allFileObject) {
			String storedFileName = file.toPath().toString();
			if(!currFiles.contains(storedFileName)) {
				file.delete(); // 파일 삭제
				log.info(" > File list to be deleted: {}", storedFileName);
			}
		}
		
		log.info(" > FileSweeper operation finished. : {}", LocalDateTime.now());
		
	}
}
