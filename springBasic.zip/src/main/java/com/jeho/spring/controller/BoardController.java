package com.jeho.spring.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.jeho.spring.domain.Paging;
import com.jeho.spring.domain.PostDTO;
import com.jeho.spring.service.BoardService;
import com.jeho.spring.utility.PagingHandler;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RequiredArgsConstructor
@RequestMapping("/board/*")
@Controller
public class BoardController {
	
	private final BoardService boardSvc;
	
	// JSP -> BoardController의 경로 이름과 여기 메서드의 return 경로 이름이 같으면 void로 생략할 수 있다.
	@GetMapping("/display")
	public String list(Model m, Paging paging) {
		log.info(" > BoardController operating: list{}", paging);
		List<PostDTO> lists = boardSvc.getList(paging);
		int totalPost = boardSvc.getTotal(paging);
		PagingHandler pagingHandler = new PagingHandler(totalPost, paging);
		
		m.addAttribute("postList", lists);
		m.addAttribute("pagingHandler", pagingHandler);
		// 어느 페이지로 갈 지 반환함.
		return "/board/list";
	}
	
	@GetMapping({"/detail", "/amend"})
	public String detail(int content, Model m, HttpServletRequest request) {
		log.info(" > BoardController operating: detail.");
		String path = request.getServletPath();
		PostDTO details = boardSvc.getDetail(content);
		m.addAttribute("detail", details);
		
		if(path.equals("/board/detail")) {
			log.info(" > Heading to detail.");
			boardSvc.increaseCount(content);
			return "/board/content";
		} else if (path.equals("/board/amend")) {
			log.info(" > Heading to modify.");
			return "/board/modify";
		} else {
			log.info(" > There's no appropriate path. Heading to Home.");
			return "/home";
		}
	}
	
	@PostMapping("/update")
	public String modifyPost(@RequestParam("num") int num, @RequestParam("title") String title, @RequestParam("content") String content) {
		boardSvc.updatePost(num, title, content);
		log.info(" > BoardController operating: modifyPost.");
		
		return "redirect:/board/detail?content=" + num;
	}
	
	@PostMapping("/assign")
	public String register(Model m) {
		log.info(" > BoardController operating: assign.");
		return "/board/list";
	}
	
	@PostMapping("/magic") // DB에 게시글을 넣어주는 magic.
	public String magic() {
		log.info("Magic Start!");
		for (int i = 1; i < 101; i++) {
			String title = String.valueOf(i*10);
			String writer = "Embugger";
			String content = String.valueOf(i*100);
			int isCompleted = boardSvc.doMagic(title, writer, content);
			log.info(isCompleted>0 ? "magic completed." : "magic failed.");
		}
		
		return "/home";
	}
}
