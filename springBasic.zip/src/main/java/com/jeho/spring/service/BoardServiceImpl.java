package com.jeho.spring.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.jeho.spring.dao.PostDAO;
import com.jeho.spring.domain.Paging;
import com.jeho.spring.domain.PostDTO;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RequiredArgsConstructor
@Service
public class BoardServiceImpl implements BoardService {
	
	private final PostDAO postDao;
	
	@Override
	public List<PostDTO> getList(Paging paging) {
		// TODO Auto-generated method stub
		return postDao.getList(paging);
	}
	
	@Override
	public PostDTO getDetail(int content) {
		return postDao.getDetail(content);
	}

	@Override
	public void increaseCount(int content) {
		postDao.increaseCount(content);
	}

	@Override
	public void updatePost(int num, String title, String content) {
		postDao.updatePost(num, title, content);	
	}

	@Override
	public int doMagic(String title, String writer, String content) {
		postDao.doMagic(title, writer, content);
		return 7;
	}

	@Override
	public int getTotal(Paging paging) {
		return postDao.getTotal(paging);
	}


}
