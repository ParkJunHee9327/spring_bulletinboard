package com.jeho.spring.service;

public interface CommentService {

}
