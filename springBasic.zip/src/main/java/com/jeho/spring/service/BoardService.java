package com.jeho.spring.service;

import java.util.List;

import com.jeho.spring.domain.Paging;
import com.jeho.spring.domain.PostDTO;

public interface BoardService {

	PostDTO getDetail(int content);

	void increaseCount(int content);

	void updatePost(int num, String title, String content);

	int doMagic(String title, String writer, String content);

	int getTotal(Paging paging);

	List<PostDTO> getList(Paging paging);

}
