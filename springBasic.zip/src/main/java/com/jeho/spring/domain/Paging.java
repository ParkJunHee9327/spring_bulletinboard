package com.jeho.spring.domain;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@AllArgsConstructor
public class Paging {
	// PagingVO에 해당함.
	// 이걸 DB용 클래스로 만든다.
	
	private int currentPage; // 현재 페이지 번호를 나타냄. pageNo
	private int postPerPage; // 한 페이지에 표시되는 글들의 수량.
	// 아래는 검색을 위한 변수들.
	// 일단 검색은 버리지만 아래 2개를 없애면 lombok의 @AllArgs에 중복이 발생해서 일단 냅둠.
	private String type;
	private String keyword;
	
	// 처음 list 페이지에 접속을 위한 기본 설정값이다.
	// lombok 생성자를 사용하면 첫 페이지 숫자가 0이 된다. 코딩에서 숫자의 시작은 0부터이므로.
	public Paging() {
		this.currentPage = 1;
		this.postPerPage = 10;
	}
	
	public Paging(int currentPage, int postPerPage) {
		this.currentPage = currentPage;
		this.postPerPage = postPerPage;
		System.out.println("Over here!" + currentPage + " " +  postPerPage);
	}
	
	// Database에서 사용될 시작 번지 구하기.
	// DB 구문: select * from post limit 번지, 개수
	public int getStartPage() {
		return (this.currentPage - 1) * this.postPerPage;
	}
	
	// 나는 list에서 파일을 직접 보여주지는 않을 거라서... 파일을 위한 메서드는 필요 없을듯?
}