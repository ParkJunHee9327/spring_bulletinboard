package com.jeho.spring.domain;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@AllArgsConstructor
@NoArgsConstructor
public class PostDTO {
	
	private long num;
	private String title;
	private String writer;
	private String content;
	private String isDel;
	private String registerDate;
	private int readCount;
	// TODO
	// private int hasFile;
}

/*
 	num bigint auto_increment,
	title varchar(500) not null,
	writer varchar(500) not null,
	content text,
	is_del varchar(5) default 'N',
	register_date datetime default now(),
	read_count int default 0,
	primary key(num)
 * */
