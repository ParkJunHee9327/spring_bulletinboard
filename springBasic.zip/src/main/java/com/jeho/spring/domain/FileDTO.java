package com.jeho.spring.domain;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@AllArgsConstructor
@NoArgsConstructor
public class FileDTO {
	
	private String uid;
	private String dirPath;
	private String fileName;
	private int fileType;
	private long postNum;
	private long fileSize;
	private String registerDate;
	
}
