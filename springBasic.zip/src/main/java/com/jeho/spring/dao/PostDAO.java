package com.jeho.spring.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.jeho.spring.domain.Paging;
import com.jeho.spring.domain.PostDTO;

public interface PostDAO {

	PostDTO getDetail(int content);

	void increaseCount(int content);

	void updatePost(@Param("num") int num, @Param("title") String title, @Param("content") String content);

	int doMagic(@Param("title") String title, @Param("writer") String writer, @Param("content") String content);

	int getTotal(Paging paging);

	List<PostDTO> getList(Paging paging);
}
