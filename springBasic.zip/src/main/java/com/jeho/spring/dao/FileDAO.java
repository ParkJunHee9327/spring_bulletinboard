package com.jeho.spring.dao;

import java.util.List;

import com.jeho.spring.domain.FileDTO;

public interface FileDAO {

	List<FileDTO> selectAllFileList();

}
