package com.ezen.spring.config;

import org.springframework.security.web.context.AbstractSecurityWebApplicationInitializer;

// AbstractSecurityWebApplicationInitializer
// 를 상속받아야 시큐리티 관련 필터들이 활성화 됨. 
public class SecurityInitalizer extends AbstractSecurityWebApplicationInitializer {

}
